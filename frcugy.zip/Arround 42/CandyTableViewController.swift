
import UIKit
import MapKit


struct Candy {
    let category : String
    let name : String
    let location : CLLocationCoordinate2D
}

class CandyTableViewController : UITableViewController, UISearchBarDelegate, UISearchDisplayDelegate {

    var candies = [Candy]()
        override func viewDidLoad() {
  
            self.candies = [Candy(category:"Europe", name:"Paris", location : CLLocationCoordinate2D (latitude: 48.85637699999999, longitude: 2.352898200000027)),
            Candy(category:"Asie", name:"Tokyo", location : CLLocationCoordinate2D (latitude: 35.7090259, longitude: 139.73199249999993)),
            Candy(category:"Amerique", name:"New York", location : CLLocationCoordinate2D (latitude: 40.7127837, longitude: -74.00594130000002))]
        self.tableView.reloadData()
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
            return self.candies.count
        
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("Cell") as UITableViewCell

        var candy : Candy
        candy = candies[indexPath.row]
        cell.textLabel.text = candy.name
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        return cell
    }

   override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "candyDetail" {
            let candyDetailViewController = segue.destinationViewController as ViewController
            
            let indexPath = self.tableView.indexPathForSelectedRow()!
               let destinationTitle = self.candies[indexPath.row].name
                candyDetailViewController.title = destinationTitle
                candyDetailViewController.location = self.candies[indexPath.row].location
            candyDetailViewController.annotation = self.candies[indexPath.row].name
           }
       }
    

    
 }
