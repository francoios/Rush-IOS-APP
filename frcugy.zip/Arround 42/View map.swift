
import UIKit
import MapKit
import CoreLocation



class ViewController: UIViewController, CLLocationManagerDelegate {
   
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    let locationManager = CLLocationManager()
   
    var location : CLLocationCoordinate2D! {
           didSet {
        
            }
    }
    var annotation : NSString! {
        didSet {
        
        }
    }
    



         @IBAction func value(sender: UISegmentedControl) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            mapView.mapType =  MKMapType.Hybrid;
        case 1:
            mapView.mapType =  MKMapType.Standard;
        case 2:
            mapView.mapType =  MKMapType.Satellite;
        default:
            break;
        }
        }

    @IBAction func Myaction(sender: AnyObject) {
        
        
            locationManager.delegate = self
            
           locationManager.desiredAccuracy = kCLLocationAccuracyBest
            
            locationManager.requestWhenInUseAuthorization()
            
            locationManager.startUpdatingLocation()
                }

      override func viewDidLoad() {
        super.viewDidLoad()
 
        mapView.mapType =  MKMapType.Hybrid;
        if (self.location == nil) {
            self.location = CLLocationCoordinate2D (
            latitude: 48.89668380000001, longitude: 2.318375500000002)
            
        let span = MKCoordinateSpanMake(0.00, 0.00)
        let region = MKCoordinateRegion(center: self.location, span: span)
        
        mapView.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.setCoordinate(self.location)
        annotation.title = "Ecole 42"
        annotation.subtitle = "Heart of Code"
        
        mapView.addAnnotation(annotation)
        }
      else
        {
            let span = MKCoordinateSpanMake(0.00, 0.00)
            let region = MKCoordinateRegion(center: self.location, span: span)
            
            mapView.setRegion(region, animated: true)
            let annotation = MKPointAnnotation()
            annotation.setCoordinate(self.location)
            annotation.title = self.annotation

             mapView.addAnnotation(annotation)

        }
       
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        
        
        
        CLGeocoder().reverseGeocodeLocation(manager.location, completionHandler: { (placemarks, error) -> Void in
            
            
            if (error != nil) {
                
                
                
                println("Error:" + error.localizedDescription)
                
                return
            }
            
            if placemarks.count > 0 {
                
                let pm = placemarks[0] as CLPlacemark
                self.displayLocationInfo(pm)
                
                
                
            }else {
                
                println("Error with data")
                
            }

        })
        

        
    }
    
    func displayLocationInfo(placemark: CLPlacemark) {
        
        
        
        self.locationManager.stopUpdatingLocation()
        let location = placemark.location.coordinate
        
        let span = MKCoordinateSpanMake(0.00, 0.00)
        let region = MKCoordinateRegion(center: location, span: span)
        
        self.mapView.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.setCoordinate(location)
        annotation.title = "You"

        self.mapView.addAnnotation(annotation)

            }

    
    
}

